daac      <- getOption("MODIStools.daac", default = "https://daac.ornl.gov")
daacmodis <- getOption("MODIStools.daacmodis", default = "https://modis.ornl.gov")
wsdl_loc  <- getOption("MODIStools.wsdl_loc", default = "/cgi-bin/MODIS/soapservice/MODIS_soapservice.pl")
